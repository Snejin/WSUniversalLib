﻿using System;

namespace WSUniversalLib
{
    public class Calculation
    {
        public static int GetQuantityForProduct(int productType, int materialType, int count, float width, float length)
        {
            // Определение коэффициента типа продукции
            double productCoefficient = 0.0;

            switch (productType)
            {
                case 1:
                    productCoefficient = 1.1;
                    break;
                case 2:
                    productCoefficient = 2.5;
                    break;
                case 3:
                    productCoefficient = 8.43;
                    break;
                default:
                    return -1; // Неизвестный тип продукции
            }

            // Определение коэффициента брака материала
            double materialDefectRate = 0.0;

            switch (materialType)
            {
                case 1:
                    materialDefectRate = 0.003;
                    break;
                case 2:
                    materialDefectRate = 0.0012;
                    break;
                default:
                    return -1; // Неизвестный тип материала
            }

            // Расчет общего необходимого сырья с учетом брака
            double rawMaterialNeeded = width * length * count * productCoefficient;
            double totalalnoeRawMaterialNeeded = rawMaterialNeeded / (1.0 - materialDefectRate);

            // Округление до ближайшего большего целого
            int okryglenieTotalRawMaterialNeeded = (int)Math.Ceiling(totalalnoeRawMaterialNeeded);

            return okryglenieTotalRawMaterialNeeded;
        }
    }
}
