﻿using WSUniversalLib;
public class Program
{
    public static void Main()
    {
        int productType = 1;
        int materialType = 2;
        int count = 10;
        float width = 1.5f;
        float length = 2.5f;

        int quantity = Calculation.GetQuantityForProduct(productType, materialType, count, width, length);
        Console.WriteLine($"Total Quantity Needed: {quantity}");
    }
}

